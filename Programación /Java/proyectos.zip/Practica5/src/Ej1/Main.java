package Ej1;

import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        String archivoProductos = "/Users/davidbravorueda/eclipse-workspace/Practica5 copia/src/productos.txt/";
        String archivoCantidades = "/Users/davidbravorueda/eclipse-workspace/Practica5 copia/src/cantidades.txt";
        String archivoSalida = "/Users/davidbravorueda/eclipse-workspace/Practica5 copia/src/resultado.txt";

        try {
            Map<String, Producto> productos = Archivo.leerProductos(archivoProductos);
            Map<String, Integer> cantidades = Archivo.leerCantidades(archivoCantidades);

            calcularTotal(productos, cantidades, archivoSalida);

        } catch (IOException e) {
            System.err.println("Error al leer los archivos: " + e.getMessage());
        }
    }

    public static void calcularTotal(Map<String, Producto> productos, Map<String, Integer> cantidades, String archivoSalida) throws IOException {
        double totalGeneral = 0;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoSalida))) {
            for (Map.Entry<String, Integer> entrada : cantidades.entrySet()) {
                String nombreProducto = entrada.getKey();
                int cantidad = entrada.getValue();

                if (productos.containsKey(nombreProducto)) {
                    Producto producto = productos.get(nombreProducto);
                    double totalProducto = producto.getPrecio() * cantidad;
                    totalGeneral += totalProducto;
                    String lineaSalida = String.format("%s;  %.2f €%n", nombreProducto, totalProducto);
                    System.out.print(lineaSalida);
                    bw.write(lineaSalida);
                }
            }
            bw.write("\n----\n");
            String totalGeneralStr = String.format("   Total = %.2f €%n", totalGeneral);
            bw.write(totalGeneralStr);
            System.out.println("\n----");
            System.out.printf("   Total = %.2f €%n", totalGeneral);
        }
    }
}
